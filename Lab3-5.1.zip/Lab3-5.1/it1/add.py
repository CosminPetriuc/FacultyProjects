def add(my_list, value):
    my_list.append(value)
    return my_list
#add a number to the end of the list
#my_list = it's the list that we want to add a number to it
#value = the number that we want to add to the list